rosrun comm_tcp client_node $1 1024
