
## Xbox Controller Driver


```
sudo apt-get install libudev-dev ncurses-dev
mkdir build && cd build
cmake ..
make -f Makefile
./xbox_ctrl_node
```

### Reference

https://github.com/elanthis/gamepad
