// Auto-generated. Do not edit!

// (in-package core_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class direction_indicator {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.straight_on = null;
      this.rotate_on = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('straight_on')) {
        this.straight_on = initObj.straight_on
      }
      else {
        this.straight_on = [];
      }
      if (initObj.hasOwnProperty('rotate_on')) {
        this.rotate_on = initObj.rotate_on
      }
      else {
        this.rotate_on = new Array(2).fill(0);
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type direction_indicator
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [straight_on]
    bufferOffset = _arraySerializer.int32(obj.straight_on, buffer, bufferOffset, null);
    // Check that the constant length array field [rotate_on] has the right length
    if (obj.rotate_on.length !== 2) {
      throw new Error('Unable to serialize array field rotate_on - length must be 2')
    }
    // Serialize message field [rotate_on]
    bufferOffset = _arraySerializer.int32(obj.rotate_on, buffer, bufferOffset, 2);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type direction_indicator
    let len;
    let data = new direction_indicator(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [straight_on]
    data.straight_on = _arrayDeserializer.int32(buffer, bufferOffset, null)
    // Deserialize message field [rotate_on]
    data.rotate_on = _arrayDeserializer.int32(buffer, bufferOffset, 2)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    length += 4 * object.straight_on.length;
    return length + 12;
  }

  static datatype() {
    // Returns string type for a message object
    return 'core_msgs/direction_indicator';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'dee1c0c07020dde4bfbc70fef9da4b52';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    Header header
    int32[] straight_on
    int32[2] rotate_on
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new direction_indicator(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.straight_on !== undefined) {
      resolved.straight_on = msg.straight_on;
    }
    else {
      resolved.straight_on = []
    }

    if (msg.rotate_on !== undefined) {
      resolved.rotate_on = msg.rotate_on;
    }
    else {
      resolved.rotate_on = new Array(2).fill(0)
    }

    return resolved;
    }
};

module.exports = direction_indicator;
