
"use strict";

let SetCompliancePunch = require('./SetCompliancePunch.js')
let RestartController = require('./RestartController.js')
let StartController = require('./StartController.js')
let TorqueEnable = require('./TorqueEnable.js')
let SetComplianceMargin = require('./SetComplianceMargin.js')
let StopController = require('./StopController.js')
let SetTorqueLimit = require('./SetTorqueLimit.js')
let SetSpeed = require('./SetSpeed.js')
let SetComplianceSlope = require('./SetComplianceSlope.js')

module.exports = {
  SetCompliancePunch: SetCompliancePunch,
  RestartController: RestartController,
  StartController: StartController,
  TorqueEnable: TorqueEnable,
  SetComplianceMargin: SetComplianceMargin,
  StopController: StopController,
  SetTorqueLimit: SetTorqueLimit,
  SetSpeed: SetSpeed,
  SetComplianceSlope: SetComplianceSlope,
};
