// Auto-generated. Do not edit!

// (in-package ros_test_service.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class SrvTestRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.req1 = null;
      this.req2 = null;
    }
    else {
      if (initObj.hasOwnProperty('req1')) {
        this.req1 = initObj.req1
      }
      else {
        this.req1 = 0;
      }
      if (initObj.hasOwnProperty('req2')) {
        this.req2 = initObj.req2
      }
      else {
        this.req2 = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SrvTestRequest
    // Serialize message field [req1]
    bufferOffset = _serializer.int64(obj.req1, buffer, bufferOffset);
    // Serialize message field [req2]
    bufferOffset = _serializer.int64(obj.req2, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SrvTestRequest
    let len;
    let data = new SrvTestRequest(null);
    // Deserialize message field [req1]
    data.req1 = _deserializer.int64(buffer, bufferOffset);
    // Deserialize message field [req2]
    data.req2 = _deserializer.int64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 16;
  }

  static datatype() {
    // Returns string type for a service object
    return 'ros_test_service/SrvTestRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '448921bea2b89b87a3e2542b2caf655c';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int64 req1
    int64 req2
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SrvTestRequest(null);
    if (msg.req1 !== undefined) {
      resolved.req1 = msg.req1;
    }
    else {
      resolved.req1 = 0
    }

    if (msg.req2 !== undefined) {
      resolved.req2 = msg.req2;
    }
    else {
      resolved.req2 = 0
    }

    return resolved;
    }
};

class SrvTestResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.result = null;
    }
    else {
      if (initObj.hasOwnProperty('result')) {
        this.result = initObj.result
      }
      else {
        this.result = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SrvTestResponse
    // Serialize message field [result]
    bufferOffset = _serializer.int64(obj.result, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SrvTestResponse
    let len;
    let data = new SrvTestResponse(null);
    // Deserialize message field [result]
    data.result = _deserializer.int64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 8;
  }

  static datatype() {
    // Returns string type for a service object
    return 'ros_test_service/SrvTestResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '9b05623554ab950ed237d43d45f0b4dd';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int64 result
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SrvTestResponse(null);
    if (msg.result !== undefined) {
      resolved.result = msg.result;
    }
    else {
      resolved.result = 0
    }

    return resolved;
    }
};

module.exports = {
  Request: SrvTestRequest,
  Response: SrvTestResponse,
  md5sum() { return '938d14e6b068645881d5435cbed82e3a'; },
  datatype() { return 'ros_test_service/SrvTest'; }
};
