
"use strict";

let SrvTest = require('./SrvTest.js')

module.exports = {
  SrvTest: SrvTest,
};
