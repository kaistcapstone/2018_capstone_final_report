
"use strict";

let MsgTest = require('./MsgTest.js');

module.exports = {
  MsgTest: MsgTest,
};
