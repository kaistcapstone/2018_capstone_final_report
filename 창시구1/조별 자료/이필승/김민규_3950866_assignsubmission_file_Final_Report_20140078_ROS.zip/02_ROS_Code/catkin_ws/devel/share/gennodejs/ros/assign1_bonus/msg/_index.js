
"use strict";

let msg2 = require('./msg2.js');
let msg1 = require('./msg1.js');

module.exports = {
  msg2: msg2,
  msg1: msg1,
};
