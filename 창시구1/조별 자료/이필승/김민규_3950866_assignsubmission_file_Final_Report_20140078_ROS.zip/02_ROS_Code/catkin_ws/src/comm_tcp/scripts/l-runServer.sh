rosrun comm_tcp server_node 1024
